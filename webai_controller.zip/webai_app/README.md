# WebAI Controller 🤖

Aplikasi Android untuk mengendalikan website menggunakan AI (Groq).

## Fitur
- 🌐 Browser terintegrasi (WebView)
- 📸 Upload foto & bandingkan dengan website
- ⚡ Inject input otomatis ke search bar website
- 🎯 Try Input: AI generate variasi, retry otomatis, popup jika berhasil

---

## Cara Build APK via GitHub (Tanpa Laptop)

### Langkah 1: Buat Akun GitHub
1. Buka **github.com** di browser HP
2. Klik **Sign up**
3. Isi email, password, username
4. Verifikasi email

### Langkah 2: Buat Repository Baru
1. Login ke GitHub
2. Klik tombol **+** (pojok kanan atas)
3. Pilih **New repository**
4. Nama repository: `webai-controller`
5. Pilih **Public**
6. Klik **Create repository**

### Langkah 3: Upload File Kode
1. Di halaman repository, klik **Add file** → **Upload files**
2. Upload semua file dari folder ini:
   - `pubspec.yaml`
   - `lib/` (semua file di dalamnya)
   - `android/` (semua file di dalamnya)
   - `.github/` (semua file di dalamnya)
3. Klik **Commit changes**

### Langkah 4: Tunggu Build Otomatis
1. Klik tab **Actions** di repository
2. Akan ada workflow **Build APK** yang berjalan otomatis
3. Tunggu sekitar **5-10 menit**
4. Jika berhasil (centang hijau ✅), klik workflow tersebut
5. Scroll ke bawah ke bagian **Artifacts**
6. Download **WebAI-Controller-APK**

### Langkah 5: Install APK
1. Extract file ZIP yang didownload
2. Install file `app-release.apk` di HP Android
3. Jika muncul peringatan "Install from unknown source", izinkan

---

## Cara Pakai Aplikasi

1. **Buka app** → Masuk ke halaman Setup
2. **Input Groq API Key** (dapatkan gratis di console.groq.com)
3. Klik **Simpan**
4. Masuk ke tab **Browser**
5. **Input URL website** yang ingin dikontrol
6. Gunakan fitur:
   - **Upload Foto** → AI bandingkan foto dengan website
   - **Kirim** → Langsung inject teks ke search bar website
   - **Try Input** → AI generate variasi & retry otomatis

---

## Catatan
- Pastikan koneksi internet aktif
- Beberapa website dengan proteksi ketat mungkin tidak bisa di-inject
- Google dan kebanyakan website umum bisa digunakan
