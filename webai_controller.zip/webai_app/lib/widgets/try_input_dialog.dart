import 'package:flutter/material.dart';

class TryInputDialog extends StatefulWidget {
  final List<String> variants;
  final Future<bool> Function(String variant) onTryVariant;
  final void Function(String successVariant) onSuccess;

  const TryInputDialog({
    super.key,
    required this.variants,
    required this.onTryVariant,
    required this.onSuccess,
  });

  @override
  State<TryInputDialog> createState() => _TryInputDialogState();
}

class _TryInputDialogState extends State<TryInputDialog> {
  int _currentIndex = 0;
  bool _isTrying = false;
  bool _autoMode = true;
  List<_VariantStatus> _statuses = [];

  @override
  void initState() {
    super.initState();
    _statuses = widget.variants
        .map((_) => _VariantStatus.pending)
        .toList();

    // Auto start
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_autoMode) _runAutoTry();
    });
  }

  Future<void> _runAutoTry() async {
    for (int i = 0; i < widget.variants.length; i++) {
      if (!mounted) return;

      setState(() {
        _currentIndex = i;
        _isTrying = true;
        _statuses[i] = _VariantStatus.trying;
      });

      await Future.delayed(const Duration(milliseconds: 800));

      try {
        final success = await widget.onTryVariant(widget.variants[i]);

        if (!mounted) return;

        if (success) {
          setState(() {
            _statuses[i] = _VariantStatus.success;
            _isTrying = false;
          });
          await Future.delayed(const Duration(milliseconds: 500));
          widget.onSuccess(widget.variants[i]);
          return;
        } else {
          setState(() {
            _statuses[i] = _VariantStatus.failed;
          });
        }
      } catch (e) {
        if (!mounted) return;
        setState(() {
          _statuses[i] = _VariantStatus.failed;
        });
      }

      await Future.delayed(const Duration(milliseconds: 500));
    }

    // All failed
    if (mounted) {
      setState(() => _isTrying = false);
    }
  }

  Future<void> _tryManual(int index) async {
    setState(() {
      _currentIndex = index;
      _isTrying = true;
      _statuses[index] = _VariantStatus.trying;
    });

    try {
      final success = await widget.onTryVariant(widget.variants[index]);
      if (!mounted) return;

      if (success) {
        setState(() {
          _statuses[index] = _VariantStatus.success;
          _isTrying = false;
        });
        await Future.delayed(const Duration(milliseconds: 300));
        widget.onSuccess(widget.variants[index]);
      } else {
        setState(() {
          _statuses[index] = _VariantStatus.failed;
          _isTrying = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _statuses[index] = _VariantStatus.failed;
        _isTrying = false;
      });
    }
  }

  Color _statusColor(_VariantStatus status) {
    switch (status) {
      case _VariantStatus.pending:
        return Colors.grey;
      case _VariantStatus.trying:
        return Colors.blue;
      case _VariantStatus.success:
        return Colors.green;
      case _VariantStatus.failed:
        return Colors.red;
    }
  }

  IconData _statusIcon(_VariantStatus status) {
    switch (status) {
      case _VariantStatus.pending:
        return Icons.radio_button_unchecked;
      case _VariantStatus.trying:
        return Icons.sync;
      case _VariantStatus.success:
        return Icons.check_circle;
      case _VariantStatus.failed:
        return Icons.cancel;
    }
  }

  @override
  Widget build(BuildContext context) {
    final allFailed = _statuses.every((s) =>
        s == _VariantStatus.failed || s == _VariantStatus.pending) &&
        !_isTrying &&
        _statuses.any((s) => s == _VariantStatus.failed);

    return AlertDialog(
      title: Row(
        children: [
          const Icon(Icons.auto_fix_high, color: Colors.purple),
          const SizedBox(width: 8),
          const Text('Try Input'),
          const Spacer(),
          if (_isTrying)
            const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
        ],
      ),
      content: SizedBox(
        width: double.maxFinite,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _isTrying
                  ? 'Mencoba variasi ${_currentIndex + 1} dari ${widget.variants.length}...'
                  : allFailed
                      ? 'Semua variasi gagal. Coba manual:'
                      : 'Pilih variasi untuk dicoba manual:',
              style: const TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 12),

            // Variants list
            ...widget.variants.asMap().entries.map((entry) {
              final i = entry.key;
              final variant = entry.value;
              final status = _statuses[i];

              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _statusColor(status).withOpacity(0.1),
                  border: Border.all(
                    color: _statusColor(status).withOpacity(0.3),
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    status == _VariantStatus.trying
                        ? SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: _statusColor(status),
                            ),
                          )
                        : Icon(
                            _statusIcon(status),
                            color: _statusColor(status),
                            size: 20,
                          ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        variant,
                        style: const TextStyle(fontSize: 13),
                      ),
                    ),
                    if (!_isTrying && status != _VariantStatus.success)
                      TextButton(
                        onPressed: () => _tryManual(i),
                        child: const Text('Coba', style: TextStyle(fontSize: 12)),
                      ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _isTrying ? null : () => Navigator.of(context).pop(),
          child: const Text('Tutup'),
        ),
        if (allFailed)
          FilledButton.icon(
            onPressed: () {
              setState(() {
                _statuses = widget.variants
                    .map((_) => _VariantStatus.pending)
                    .toList();
              });
              _runAutoTry();
            },
            icon: const Icon(Icons.refresh, size: 16),
            label: const Text('Coba Lagi'),
          ),
      ],
    );
  }
}

enum _VariantStatus { pending, trying, success, failed }
