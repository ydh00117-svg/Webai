import 'package:flutter/material.dart';

class AppState extends ChangeNotifier {
  String groqApiKey = '';
  String websiteUrl = '';
  String? uploadedImagePath;
  String comparisonResult = '';
  bool isLoading = false;
  bool isInjecting = false;
  List<String> tryInputVariants = [];
  String? successfulVariant;

  void setApiKey(String key) {
    groqApiKey = key;
    notifyListeners();
  }

  void setUrl(String url) {
    websiteUrl = url;
    notifyListeners();
  }

  void setImagePath(String? path) {
    uploadedImagePath = path;
    notifyListeners();
  }

  void setComparisonResult(String result) {
    comparisonResult = result;
    notifyListeners();
  }

  void setLoading(bool val) {
    isLoading = val;
    notifyListeners();
  }

  void setInjecting(bool val) {
    isInjecting = val;
    notifyListeners();
  }

  void setTryInputVariants(List<String> variants) {
    tryInputVariants = variants;
    notifyListeners();
  }

  void setSuccessfulVariant(String? variant) {
    successfulVariant = variant;
    notifyListeners();
  }

  void reset() {
    comparisonResult = '';
    tryInputVariants = [];
    successfulVariant = null;
    isLoading = false;
    isInjecting = false;
    notifyListeners();
  }
}
