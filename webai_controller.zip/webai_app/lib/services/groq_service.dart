import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class GroqService {
  final String apiKey;
  static const String baseUrl = 'https://api.groq.com/openai/v1/chat/completions';

  GroqService(this.apiKey);

  Map<String, String> get _headers => {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      };

  /// Compare uploaded image with website screenshot description
  Future<String> compareImageWithWebsite({
    required String imagePath,
    required String websiteUrl,
    required String websiteContent,
  }) async {
    final imageBytes = await File(imagePath).readAsBytes();
    final base64Image = base64Encode(imageBytes);

    final body = jsonEncode({
      'model': 'llama-3.2-11b-vision-preview',
      'messages': [
        {
          'role': 'user',
          'content': [
            {
              'type': 'image_url',
              'image_url': {
                'url': 'data:image/jpeg;base64,$base64Image',
              },
            },
            {
              'type': 'text',
              'text': '''Bandingkan gambar yang diberikan dengan konten website berikut.
Website URL: $websiteUrl
Konten website: $websiteContent

Jelaskan:
1. Apakah gambar dan website menunjukkan halaman yang sama?
2. Perbedaan yang ada antara gambar dan website saat ini
3. Elemen input/search bar yang tersedia di website

Jawab dalam Bahasa Indonesia.''',
            },
          ],
        },
      ],
      'max_tokens': 1024,
    });

    final response = await http.post(
      Uri.parse(baseUrl),
      headers: _headers,
      body: body,
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['choices'][0]['message']['content'];
    } else {
      throw Exception('Groq API error: ${response.statusCode} - ${response.body}');
    }
  }

  /// Generate input variants for try input feature
  Future<List<String>> generateInputVariants({
    required String userInstruction,
    required String websiteUrl,
    required String websiteContent,
    int count = 5,
  }) async {
    final body = jsonEncode({
      'model': 'llama-3.3-70b-versatile',
      'messages': [
        {
          'role': 'system',
          'content': '''Kamu adalah AI yang membantu menggenerate variasi input untuk website.
Tugasmu adalah menggenerate $count variasi input berdasarkan instruksi user.
Jawab HANYA dengan JSON array berisi string variasi input.
Contoh format: ["variasi 1", "variasi 2", "variasi 3"]
Jangan tambahkan penjelasan apapun, hanya JSON array.''',
        },
        {
          'role': 'user',
          'content': '''Website: $websiteUrl
Instruksi user: $userInstruction
Konten website: $websiteContent

Generate $count variasi input yang berbeda untuk dimasukkan ke search bar/input field website ini.''',
        },
      ],
      'max_tokens': 512,
      'temperature': 0.8,
    });

    final response = await http.post(
      Uri.parse(baseUrl),
      headers: _headers,
      body: body,
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final content = data['choices'][0]['message']['content'] as String;

      // Parse JSON array from response
      final cleanContent = content.trim();
      final jsonStart = cleanContent.indexOf('[');
      final jsonEnd = cleanContent.lastIndexOf(']') + 1;

      if (jsonStart != -1 && jsonEnd > jsonStart) {
        final jsonStr = cleanContent.substring(jsonStart, jsonEnd);
        final List<dynamic> variants = jsonDecode(jsonStr);
        return variants.map((v) => v.toString()).toList();
      }

      // Fallback: split by newlines if JSON parsing fails
      return content
          .split('\n')
          .where((line) => line.trim().isNotEmpty)
          .take(count)
          .toList();
    } else {
      throw Exception('Groq API error: ${response.statusCode}');
    }
  }

  /// Simple chat completion
  Future<String> chat(String prompt) async {
    final body = jsonEncode({
      'model': 'llama-3.3-70b-versatile',
      'messages': [
        {'role': 'user', 'content': prompt},
      ],
      'max_tokens': 512,
    });

    final response = await http.post(
      Uri.parse(baseUrl),
      headers: _headers,
      body: body,
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['choices'][0]['message']['content'];
    } else {
      throw Exception('Groq API error: ${response.statusCode}');
    }
  }
}
