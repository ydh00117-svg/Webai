import 'package:webview_flutter/webview_flutter.dart';

class WebViewService {
  final WebViewController controller;

  WebViewService(this.controller);

  /// Get current page content/title for AI analysis
  Future<String> getPageContent() async {
    try {
      final title = await controller.getTitle() ?? '';
      final url = await controller.currentUrl() ?? '';

      // Get visible text content from page
      final content = await controller.runJavaScriptReturningResult('''
        (function() {
          var text = document.body ? document.body.innerText : '';
          var inputs = Array.from(document.querySelectorAll('input, textarea, [role="searchbox"], [type="search"]'))
            .map(function(el) {
              return {
                tag: el.tagName,
                type: el.type || '',
                placeholder: el.placeholder || '',
                name: el.name || '',
                id: el.id || ''
              };
            });
          return JSON.stringify({
            title: document.title,
            url: window.location.href,
            textPreview: text.substring(0, 500),
            inputs: inputs
          });
        })();
      ''');

      return 'URL: $url\nTitle: $title\nContent: $content';
    } catch (e) {
      return 'URL: ${await controller.currentUrl()}\nTitle: ${await controller.getTitle()}';
    }
  }

  /// Inject text into the first available search bar / input field
  Future<bool> injectToSearchBar(String text) async {
    try {
      final result = await controller.runJavaScriptReturningResult('''
        (function() {
          // Priority selectors for search/input fields
          var selectors = [
            'input[type="search"]',
            'input[name="q"]',
            'input[name="search"]',
            'input[placeholder*="Search" i]',
            'input[placeholder*="Cari" i]',
            'input[role="searchbox"]',
            '[role="searchbox"]',
            'textarea[name="q"]',
            'input[type="text"]:not([type="hidden"])',
            'textarea',
          ];

          var inputEl = null;

          for (var i = 0; i < selectors.length; i++) {
            var el = document.querySelector(selectors[i]);
            if (el && el.offsetParent !== null) {
              inputEl = el;
              break;
            }
          }

          if (!inputEl) return 'NOT_FOUND';

          // Focus and set value
          inputEl.focus();
          inputEl.click();

          // Native input value setter for React/Vue compatibility
          var nativeInputValueSetter = Object.getOwnPropertyDescriptor(
            window.HTMLInputElement.prototype, 'value'
          ) || Object.getOwnPropertyDescriptor(
            window.HTMLTextAreaElement.prototype, 'value'
          );

          if (nativeInputValueSetter) {
            nativeInputValueSetter.set.call(inputEl, "${text.replaceAll('"', '\\"')}");
          } else {
            inputEl.value = "${text.replaceAll('"', '\\"')}";
          }

          // Dispatch events to trigger website's listeners
          inputEl.dispatchEvent(new Event('input', { bubbles: true }));
          inputEl.dispatchEvent(new Event('change', { bubbles: true }));
          inputEl.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
          inputEl.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));

          return 'SUCCESS:' + inputEl.tagName + ':' + (inputEl.id || inputEl.name || 'unknown');
        })();
      ''');

      final resultStr = result.toString().replaceAll('"', '');
      return resultStr.startsWith('SUCCESS');
    } catch (e) {
      return false;
    }
  }

  /// Submit/press Enter after injecting
  Future<void> submitInput() async {
    try {
      await controller.runJavaScript('''
        (function() {
          var selectors = [
            'input[type="search"]',
            'input[name="q"]',
            'input[type="text"]',
            'textarea',
          ];

          var inputEl = null;
          for (var i = 0; i < selectors.length; i++) {
            var el = document.querySelector(selectors[i]);
            if (el && el.offsetParent !== null) {
              inputEl = el;
              break;
            }
          }

          if (inputEl) {
            // Press Enter
            inputEl.dispatchEvent(new KeyboardEvent('keypress', {
              key: 'Enter', keyCode: 13, bubbles: true
            }));
            inputEl.dispatchEvent(new KeyboardEvent('keydown', {
              key: 'Enter', keyCode: 13, bubbles: true
            }));
          }

          // Also try submitting the form
          var form = inputEl ? inputEl.closest('form') : document.querySelector('form');
          if (form) form.submit();
        })();
      ''');
    } catch (e) {
      // Ignore submit errors
    }
  }

  /// Check if page changed (to detect success)
  Future<String> getCurrentUrl() async {
    return await controller.currentUrl() ?? '';
  }

  /// Take screenshot via JS canvas
  Future<String?> capturePageScreenshot() async {
    try {
      final result = await controller.runJavaScriptReturningResult('''
        (function() {
          return document.title + ' | ' + window.location.href;
        })();
      ''');
      return result.toString();
    } catch (e) {
      return null;
    }
  }
}
