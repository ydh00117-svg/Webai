import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:image_picker/image_picker.dart';
import '../services/app_state.dart';
import '../services/groq_service.dart';
import '../services/webview_service.dart';
import '../widgets/try_input_dialog.dart';
import '../widgets/success_popup.dart';

class BrowserScreen extends StatefulWidget {
  const BrowserScreen({super.key});

  @override
  State<BrowserScreen> createState() => _BrowserScreenState();
}

class _BrowserScreenState extends State<BrowserScreen> {
  late WebViewController _webViewController;
  late WebViewService _webViewService;
  final _urlController = TextEditingController(text: 'https://www.google.com');
  final _inputController = TextEditingController();
  bool _panelExpanded = true;
  bool _webViewReady = false;
  double _loadingProgress = 0;

  @override
  void initState() {
    super.initState();
    _initWebView();
  }

  void _initWebView() {
    _webViewController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onProgress: (progress) {
          setState(() => _loadingProgress = progress / 100);
        },
        onPageStarted: (_) => setState(() => _webViewReady = false),
        onPageFinished: (_) => setState(() {
          _webViewReady = true;
          _loadingProgress = 0;
        }),
        onWebResourceError: (error) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Error: ${error.description}')),
            );
          }
        },
      ))
      ..loadRequest(Uri.parse('https://www.google.com'));

    _webViewService = WebViewService(_webViewController);
  }

  void _loadUrl() {
    var url = _urlController.text.trim();
    if (!url.startsWith('http')) url = 'https://$url';
    _webViewController.loadRequest(Uri.parse(url));
    context.read<AppState>().setUrl(url);
  }

  Future<void> _pickAndCompareImage() async {
    final appState = context.read<AppState>();
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);

    if (picked == null) return;

    appState.setImagePath(picked.path);
    appState.setLoading(true);

    try {
      final pageContent = await _webViewService.getPageContent();
      final groq = GroqService(appState.groqApiKey);

      final result = await groq.compareImageWithWebsite(
        imagePath: picked.path,
        websiteUrl: _urlController.text,
        websiteContent: pageContent,
      );

      appState.setComparisonResult(result);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error analisis: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      appState.setLoading(false);
    }
  }

  Future<void> _injectInput() async {
    final text = _inputController.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Masukkan teks arahan terlebih dahulu')),
      );
      return;
    }

    final appState = context.read<AppState>();
    appState.setInjecting(true);

    try {
      final success = await _webViewService.injectToSearchBar(text);
      if (success) {
        await Future.delayed(const Duration(milliseconds: 300));
        await _webViewService.submitInput();
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('✅ Input berhasil dikirim!'),
              backgroundColor: Colors.green,
            ),
          );
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('❌ Tidak ditemukan input field di halaman ini'),
              backgroundColor: Colors.orange,
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      appState.setInjecting(false);
    }
  }

  Future<void> _startTryInput() async {
    final text = _inputController.text.trim();
    if (text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Masukkan instruksi terlebih dahulu')),
      );
      return;
    }

    final appState = context.read<AppState>();
    appState.setLoading(true);

    try {
      final pageContent = await _webViewService.getPageContent();
      final groq = GroqService(appState.groqApiKey);

      // Generate variants
      final variants = await groq.generateInputVariants(
        userInstruction: text,
        websiteUrl: _urlController.text,
        websiteContent: pageContent,
      );

      appState.setTryInputVariants(variants);
      appState.setLoading(false);

      if (!mounted) return;

      // Show try input dialog
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => TryInputDialog(
          variants: variants,
          onTryVariant: (variant) async {
            final success = await _webViewService.injectToSearchBar(variant);
            if (success) {
              await Future.delayed(const Duration(milliseconds: 300));
              await _webViewService.submitInput();
            }
            return success;
          },
          onSuccess: (successVariant) {
            appState.setSuccessfulVariant(successVariant);
            Navigator.of(context).pop();
            // Show success popup
            showDialog(
              context: context,
              builder: (_) => SuccessPopup(successfulVariant: successVariant),
            );
          },
        ),
      );
    } catch (e) {
      appState.setLoading(false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
        );
      }
    }
  }

  @override
  void dispose() {
    _urlController.dispose();
    _inputController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('WebAI Controller'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(_panelExpanded ? Icons.expand_less : Icons.expand_more),
            onPressed: () => setState(() => _panelExpanded = !_panelExpanded),
            tooltip: 'Toggle Panel',
          ),
        ],
      ),
      body: Column(
        children: [
          // URL Bar
          Container(
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _urlController,
                    decoration: InputDecoration(
                      hintText: 'Masukkan URL website...',
                      prefixIcon: const Icon(Icons.link, size: 20),
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      isDense: true,
                    ),
                    onSubmitted: (_) => _loadUrl(),
                    keyboardType: TextInputType.url,
                  ),
                ),
                const SizedBox(width: 8),
                IconButton.filled(
                  onPressed: _loadUrl,
                  icon: const Icon(Icons.arrow_forward),
                  style: IconButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Loading indicator
          if (_loadingProgress > 0 && _loadingProgress < 1)
            LinearProgressIndicator(value: _loadingProgress),

          // WebView
          Expanded(
            child: WebViewWidget(controller: _webViewController),
          ),

          // AI Control Panel
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            height: _panelExpanded ? null : 0,
            child: _panelExpanded
                ? _buildControlPanel(appState)
                : const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }

  Widget _buildControlPanel(AppState appState) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          // Panel title
          Row(
            children: [
              const Icon(Icons.smart_toy, size: 18),
              const SizedBox(width: 8),
              const Text(
                'AI Control Panel',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              const Spacer(),
              if (appState.isLoading || appState.isInjecting)
                const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
            ],
          ),

          const SizedBox(height: 12),

          // Comparison result
          if (appState.comparisonResult.isNotEmpty) ...[
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceVariant,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Hasil Analisis AI:',
                    style: TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 12),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    appState.comparisonResult,
                    style: const TextStyle(fontSize: 12),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],

          // Input field
          TextField(
            controller: _inputController,
            decoration: InputDecoration(
              hintText: 'Masukkan arahan (contoh: cari laptop murah)...',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              isDense: true,
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            ),
            maxLines: 2,
          ),

          const SizedBox(height: 12),

          // Action buttons
          Row(
            children: [
              // Compare photo button
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: appState.isLoading ? null : _pickAndCompareImage,
                  icon: Icon(
                    appState.uploadedImagePath != null
                        ? Icons.check_circle
                        : Icons.add_photo_alternate,
                    size: 16,
                  ),
                  label: Text(
                    appState.uploadedImagePath != null
                        ? 'Foto ✓'
                        : 'Upload Foto',
                    style: const TextStyle(fontSize: 12),
                  ),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 8),

              // Inject button
              Expanded(
                child: FilledButton.icon(
                  onPressed: appState.isInjecting || !_webViewReady
                      ? null
                      : _injectInput,
                  icon: const Icon(Icons.send, size: 16),
                  label: const Text('Kirim', style: TextStyle(fontSize: 12)),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),

              const SizedBox(width: 8),

              // Try Input button
              Expanded(
                child: FilledButton.icon(
                  onPressed: appState.isLoading || !_webViewReady
                      ? null
                      : _startTryInput,
                  icon: const Icon(Icons.auto_fix_high, size: 16),
                  label: const Text('Try Input', style: TextStyle(fontSize: 12)),
                  style: FilledButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.tertiary,
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
